<?php
/* Plugin Name: Podcaster Widgets
 * Plugin URI: http://www.themestation.co/plugins
 * Description: Add useful widgets to your Podcaster website.
 * Version: 1.0
 * Author: Theme Station
 * Author URI: http://www.themestation.co
 */

if ( ! defined( 'ABSPATH' ) ) exit; 
// Exit if accessed directly

class PodWidgets {
	function __construct(){
		
    	/* Plugin folder path */
    	if ( ! defined( 'PODWD_PLUGIN_DIR' ) ) {
    		define( 'PODWD_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
    	}

    	/* Plugin folder URL */
    	if ( ! defined( 'PODWD_PLUGIN_URL' ) ) {
    		define( 'PODWD_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
    	}
    	

        /* Load Widgets */
       	require_once( PODWD_PLUGIN_DIR .'includes/widget-highlightcategory.php' );
        require_once( PODWD_PLUGIN_DIR .'includes/widget-recentcomments.php' );
        require_once( PODWD_PLUGIN_DIR .'includes/widget-recentposts.php' );    	

    	add_action( 'init', array( $this, 'init' ) );
	}

	
	function init(){
		if( ! is_admin() ){
            
            /* Scripts */
            wp_enqueue_script( 'jquery' );
            wp_enqueue_script( 'jquery-ui-tabs' );
            wp_enqueue_script( 'jquery-ui-accordion' );

            /* Handles widgets */
            wp_enqueue_script( 'podwd-recentp-tabs', PODWD_PLUGIN_URL . 'assets/js/podwd-recent-posts.js', array('jquery', 'jquery-ui-accordion'), '1.0', true );
            wp_enqueue_script( 'podwd-call-ui-tabs', PODWD_PLUGIN_URL . 'assets/js/call-ui-tabs.js', array('jquery', 'jquery-ui-tabs'), '1.0', true ); 

            /* CSS */
            wp_enqueue_style( 'podwd-widgets-css', PODWD_PLUGIN_URL . 'assets/css/podwd-widgets.css' );

        }
	}
}
new PodWidgets(); ?>