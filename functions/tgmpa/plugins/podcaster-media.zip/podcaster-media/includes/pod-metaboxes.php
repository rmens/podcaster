<?php
/**
 *
 * @category Podcaster Media
 * @package  podcaster-media
 */

/**
 * pod_media_get_plugin_active()
 * Finds out which plugin for podcasting is active.
 *
 * @return string $plgn appreviated name of the plugin.
 */
if( ! function_exists('pod_media_get_plugin_active') ) {
	function pod_media_get_plugin_active() {
		if( class_exists( 'SSP_Admin' ) ) {
			$plgn = 'ssp';
		} elseif( function_exists('powerpress_content') ) {
			$plgn = 'bpp';
		} else {
			$plgn = '';
		}
		return $plgn;
	}
}
add_action( 'plugins_loaded', 'pod_media_get_plugin_active' );

$podcast_plugin_active = pod_media_get_plugin_active();

if ( file_exists( dirname( __FILE__ ) . '/cmb2/init.php' ) ) {
	require_once dirname( __FILE__ ) . '/cmb2/init.php';
} elseif ( file_exists( dirname( __FILE__ ) . '/CMB2/init.php' ) ) {
	require_once dirname( __FILE__ ) . '/CMB2/init.php';
}

/**
 * Conditionally displays a metabox when used as a callback in the 'show_on_cb' cmb2_box parameter
 *
 * @param  CMB2 $cmb CMB2 object.
 *
 * @return bool      True if metabox should show
 */
function podmedmetab_show_if_front_page( $cmb ) {
	// Don't show this metabox if it's not the front page template.
	if ( get_option( 'page_on_front' ) !== $cmb->object_id ) {
		return false;
	}
	return true;
}

/**
 * Conditionally displays a field when used as a callback in the 'show_on_cb' field parameter
 *
 * @param  CMB2_Field $field Field object.
 *
 * @return bool              True if metabox should show
 */
function podmedmetab_hide_if_no_cats( $field ) {
	// Don't show this field if not in the cats category.
	if ( ! has_tag( 'cats', $field->object_id ) ) {
		return false;
	}
	return true;
}


if( $podcast_plugin_active == "ssp" ) {
	/**
	 * Gets a number of terms and displays them as options
	 * @param  string       $taxonomy Taxonomy terms to retrieve. Default is category.
	 * @param  string|array $args     Optional. get_terms optional arguments
	 * @return array                  An array of options that matches the CMB2 options array
	 */
	function podmedmetab_get_term_options2( $taxonomy = array('series', 'category' ), $args = array() ) {

	    $args['taxonomy'] = $taxonomy;

	    $args = wp_parse_args( $args, array( 'taxonomy' => array('series', 'category' ) ) );

	    $taxonomy = $args['taxonomy'];

	    $terms = (array) get_terms( $taxonomy, $args );

	    // Initate an empty array
	    $term_options = array();
	    if ( ! empty( $terms ) ) {
	        foreach ( $terms as $term ) {
	            $term_options[ $term->term_id ] = $term->name;
	        }
	    }

	    return $term_options;
	}
} else {
	/**
	 * Gets a number of terms and displays them as options
	 * @param  string       $taxonomy Taxonomy terms to retrieve. Default is category.
	 * @param  string|array $args     Optional. get_terms optional arguments
	 * @return array                  An array of options that matches the CMB2 options array
	 */
	function podmedmetab_get_term_options( $taxonomy = 'category', $args = array() ) {

	    $args['taxonomy'] = $taxonomy;
	    // $defaults = array( 'taxonomy' => 'category' );
	    $args = wp_parse_args( $args, array( 'taxonomy' => 'category' ) );

	    $taxonomy = $args['taxonomy'];

	    $terms = (array) get_terms( $taxonomy, $args );

	    // Initate an empty array
	    $term_options = array();
	    if ( ! empty( $terms ) ) {
	        foreach ( $terms as $term ) {
	            $term_options[ $term->term_id ] = $term->name;
	        }
	    }

	    return $term_options;
	}
}


/**
 * Hook in and add a demo metabox. Can only happen on the 'cmb2_admin_init' or 'cmb2_init' hook.
 */
add_action( 'cmb2_admin_init', 'podmedmetab_register_metabox' );
function podmedmetab_register_metabox() {
	$prefix = 'cmb_';

	$options = get_option('podcaster-theme');
	$feat_head_type = isset( $options['pod-featured-header-type'] ) ? $options['pod-featured-header-type'] : '';
	$feat_head_cont = isset( $options['pod-featured-header-content'] ) ? $options['pod-featured-header-content'] : '';


	$podcast_plugin_active = pod_media_get_plugin_active();

	if( $feat_head_type == 'static-posts' || $feat_head_type == 'slideshow' ){
		$cmb_featured_post = new_cmb2_box( array(
			'id'            => 'thst_featured_post',
			'title'         => esc_html__( 'Featured Post', 'podcaster-media' ),
			'object_types'  => array( 'post', 'podcast' ),
			'context'    => 'side',
			'priority'   => 'default',
			'show_names' => true, 
		) );

		$cmb_featured_post->add_field( array(
			'name' => esc_html__( 'Feature Post', 'podcaster-media' ),
			'desc' => esc_html__( 'Tick the box to feature this post on the front page.', 'podcaster-media' ),
			'id'   => $prefix . 'thst_feature_post',
			'type' => 'checkbox',
		) );
		$cmb_featured_post->add_field( array(
			'name' => esc_html__( 'Featured Post Header', 'podcaster-media' ),
			'desc' => esc_html__( 'Upload an image or enter an URL.', 'podcaster-media' ),
			'id'   => $prefix . 'thst_feature_post_img',
			'type' => 'file',
			'allow' => array( 'url', 'attachment' )
		) );
		$cmb_featured_post->add_field( array(
			'name'    => esc_html__( 'Alignment', 'podcaster-media' ),
			'desc'    => esc_html__( 'Select the alignment of your header.', 'podcaster-media' ),
			'id'      => $prefix . 'thst_feature_post_align',
			'type'    => 'select',
			'show_option_none' => true,
			'options'          => array(
				'text-align:left;' 		=> esc_html__( 'Left', 'podcaster-media' ),
				'text-align:center;'	=> esc_html__( 'Center', 'podcaster-media' ),
				'text-align:right;'		=> esc_html__( 'Right', 'podcaster-media' ),
			),
		) );
		$cmb_featured_post->add_field( array(
			'name'    => esc_html__( 'Background Style', 'podcaster-media' ),
			'desc'    => esc_html__( 'Choose how you would like to display the background image.', 'podcaster-media' ),
			'id'      => $prefix . 'thst_page_header_bgstyle',
			'type'    => 'radio',
			'options' => array(
				'background-size:contain;'	=> esc_html__( 'Tiled', 'podcaster-media' ),
				'background-size:cover;'	=> esc_html__( 'Stretched', 'podcaster-media' ),
			),
			'default' => 'background-size:cover;',
		) );
		$cmb_featured_post->add_field( array(
			'name' => esc_html__( 'Display Excerpt', 'podcaster-media' ),
			'desc' => esc_html__( 'Tick the box to display an excerpt.', 'podcaster-media' ),
			'id'   => $prefix . 'thst_feature_post_excerpt',
			'type' => 'checkbox',
		) );
		$cmb_featured_post->add_field( array(
		    'name' => esc_html__('Excerpt Word Count', 'podcaster-media'),
		    'desc' => esc_html__('Enter the amount of words you want to display in your excerpt. Leaving it blank with default to 25 words.', 'podcaster-media'),
		    'id' => $prefix . 'thst_featured_post_excerpt_count',
		    'type' => 'text_small'
		) );
		$cmb_featured_post->add_field( array(
			'name' => esc_html__( 'Parallax', 'podcaster-media' ),
			'desc' => esc_html__( 'Tick the box to activate parallax background scrolling.', 'podcaster-media' ),
			'id'   => $prefix . 'thst_feature_post_para',
			'type' => 'checkbox',
		) );
	}

	if( $podcast_plugin_active != 'bpp' && $podcast_plugin_active != 'ssp' ) {

		$cmb_featured_audio = new_cmb2_box( array(
			'id'            => 'thst_featured_audio',
			'title'         => esc_html__( 'Featured Audio', 'podcaster-media' ),
			'object_types'  => array( 'post' ),
			'context'    => 'normal',
			'priority'   => 'high',
			'show_names' => true, 
		) );
		$cmb_featured_audio->add_field( array(
		    'name'    => esc_html__('Audio Type', 'podcaster-media'),
		    'id'      => $prefix . 'thst_audio_type',
		    'type'    => 'radio_inline',
		    'options' => array(
		        'audio-url' => esc_html__( 'Audio File (URL)', 'podcaster-media' ),
		        'audio-embed-url'   => esc_html__( 'Audio Embed (URL)', 'podcaster-media' ),
		        'audio-embed-code'     => esc_html__( 'Audio Embed (Code)', 'podcaster-media' ),
		        'audio-playlist'     => esc_html__( 'Audio Playlist', 'podcaster-media' ),
		    ),
		    'default' => 'audio-url',
		) );
		$cmb_featured_audio->add_field( array(
			'name' => esc_html__( 'Audio URL', 'podcaster-media' ),
			'desc' => esc_html__( 'Upload an audio file or enter a URL that ends with a file extension, such as <strong>*.mp3</strong>.', 'podcaster-media' ),
			'id'   => $prefix . 'thst_audio_url',
			'type' => 'file',
		) );
		$cmb_featured_audio->add_field( array(
			'name' => esc_html__( 'Audio Embed URL', 'podcaster-media' ),
			'desc' => esc_html__( 'Enter your embed URL here. URL\'s posted here should  not end on <strong>*.mp3</strong> or other file extensions. Supported websites are: YouTube, Vimeo, Hulu, DailyMotion, Flickr Video and Qik.', 'podcaster-media' ),
			'id'   => $prefix . 'thst_audio_embed',
			'type' => 'oembed',
		) );
		$cmb_featured_audio->add_field( array(
			'name' => esc_html__( 'Audio Embed Code', 'podcaster-media' ),
			'desc' => esc_html__( 'Paste your embed code here.', 'podcaster-media' ),
			'id'   => $prefix . 'thst_audio_embed_code',
			'type' => 'textarea_code',
			'options' => array( 'disable_codemirror' => true ),
		) );		
		$cmb_featured_audio->add_field( array(
			'name' => esc_html__( 'Audio Playlist', 'podcaster-media' ),
			'desc' => esc_html__( 'Upload audio to be displayed in a playlist. (Only works with uploads.)', 'podcaster-media' ),
			'id'   => $prefix . 'thst_audio_playlist',
			'type' => 'file_list',
		) );
		$cmb_featured_audio->add_field( array(
			'name' => esc_html__( 'Audio Caption', 'podcaster-media' ),
			'desc' => esc_html__( 'Enter a short audio caption.(optional)', 'podcaster-media' ),
			'id'   => $prefix . 'thst_audio_capt',
			'type' => 'text',
		) );
		$cmb_featured_audio->add_field( array(
			'name' => esc_html__( 'Allow Download', 'podcaster-media' ),
			'desc' => esc_html__( 'Check this box if you would like your users to be able to download your audio file. (Might not work with files hosted on Soundcloud.)', 'podcaster-media' ),
			'id'   => $prefix . 'thst_audio_download',
			'type' => 'checkbox',
		) );
		$cmb_featured_audio->add_field( array(
			'name' => esc_html__( 'Explicit', 'podcaster-media' ),
			'desc' => esc_html__( 'Please check this box if you would like your post to be marked as explicit.', 'podcaster-media' ),
			'id'   => $prefix . 'thst_audio_explicit',
			'type' => 'checkbox',
		) );


		$cmb_featured_video = new_cmb2_box( array(
			'id'            => 'thst_featured_video',
			'title'         => esc_html__( 'Featured Video', 'podcaster-media' ),
			'object_types'  => array( 'post' ),
			'context'    => 'normal',
			'priority'   => 'high',
			'show_names' => true, 
		) );
		$cmb_featured_video->add_field( array(
		    'name'    => 'Video Type',
		    'id'      => $prefix . 'thst_video_type',
		    'type'    => 'radio_inline',
		    'options' => array(
		        'video-oembed' => esc_html__( 'Video oEmbed Code', 'podcaster-media' ),
		        'video-embed-url'   => esc_html__( 'Video Embed Code', 'podcaster-media' ),
		        'video-url'     => esc_html__( 'Video URL (Upload/Self-Hosted)', 'podcaster-media' ),
		        'video-playlist'     => esc_html__( 'Video Playlist', 'podcaster-media' ),
		    ),
		    'default' => 'video-oembed',
		) );
		$cmb_featured_video->add_field( array(
			'name' => esc_html__( 'Video oEmbed Code', 'podcaster-media' ),
			'desc' => esc_html__( 'Enter your oembed code here. Supported websites are: YouTube, Vimeo, Hulu, DailyMotion, Flickr Video and Qik.', 'podcaster-media' ),
			'id'   => $prefix . 'thst_video_embed',
			'type' => 'oembed',
		) );
		$cmb_featured_video->add_field( array(
			'name' => esc_html__( 'Video Embed Code', 'podcaster-media' ),
			'desc' => esc_html__( 'Paste your embed code here.', 'podcaster-media' ),
			'id'   => $prefix . 'thst_video_embed_code',
			'type' => 'textarea_code',
			'options' => array( 'disable_codemirror' => true ),
		) );
		$cmb_featured_video->add_field( array(
			'name' => esc_html__( 'Video URL', 'podcaster-media'),
			'desc' => esc_html__( 'Upload a video file or enter an URL.', 'podcaster-media' ),
			'id'   => $prefix . 'thst_video_url',
			'type' => 'file',
		) );
		$cmb_featured_video->add_field( array(
			'name' => esc_html__( 'Video Playlist', 'podcaster-media' ),
			'desc' => esc_html__( 'Upload videos to be displayed in a playlist.(Only works with uploads.)', 'podcaster-media' ),
			'id'   => $prefix . 'thst_video_playlist',
			'type' => 'file_list',
		) );
		$cmb_featured_video->add_field( array(
			'name' => esc_html__( 'Thumbnail', 'podcaster-media' ),
			'desc' => esc_html__( 'Upload a thumbnail for your video. You only need to do this if you are hosting it yourself.', 'podcaster-media' ),
			'id'   => $prefix . 'thst_video_thumb',
			'type' => 'file',
		) );
		$cmb_featured_video->add_field( array(
			'name' => esc_html__( 'Caption', 'podcaster-media' ),
			'desc' => esc_html__( 'Enter a short video caption.(optional)', 'podcaster-media' ),
			'id'   => $prefix . 'thst_video_capt',
			'type' => 'text',
		) );
		$cmb_featured_video->add_field( array(
			'name' => esc_html__( 'Allow Download', 'podcaster-media' ),
			'desc' => esc_html__( 'Check this box if you would like your users to be able to download your video file. (Only works with self-hosted files.)', 'podcaster-media' ),
			'id'   => $prefix . 'thst_video_download',
			'type' => 'checkbox',
		) );
		$cmb_featured_video->add_field( array(
			'name' => esc_html__( 'Explicit', 'podcaster-media' ),
			'desc' => esc_html__( 'Please check this box if you would like your post to be marked as explicit.', 'podcaster-media' ),
			'id'   => $prefix . 'thst_video_explicit',
			'type' => 'checkbox',
		) );
	}
}