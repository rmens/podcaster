<?php
/**
 * Check if Block Editor is active.
 * Must only be used after plugins_loaded action is fired.
 *
 * @return bool
 */
if( ! function_exists("pod_media_is_gutenberg_active") ){
	function pod_media_is_gutenberg_active() {
	    // Gutenberg plugin is installed and activated.
	    $gutenberg = ! ( false === has_filter( 'replace_editor', 'gutenberg_init' ) );

	    // Block editor since 5.0.
	    $block_editor = version_compare( $GLOBALS['wp_version'], '5.0-beta', '>' );


	    if ( ! $gutenberg && ! $block_editor ) {
	        return false;
	    }

	    if ( pod_media_is_classic_editor_plugin_active() ) {
	        $editor_option       = get_option( 'classic-editor-replace' );
	        $block_editor_active = array( 'no-replace', 'block' );

	        return in_array( $editor_option, $block_editor_active, true );
	    }

	    return true;
	}
}

/**
 * Check if Classic Editor plugin is active.
 *
 * @return bool
 */

if( ! function_exists("pod_media_is_classic_editor_plugin_active") ){
	function pod_media_is_classic_editor_plugin_active() {
	    if ( ! function_exists( 'is_plugin_active' ) ) {
	        include_once ABSPATH . 'wp-admin/includes/plugin.php';
	    }

	    if ( is_plugin_active( 'classic-editor/classic-editor.php' ) ) {
	        return true;
	    }

	    return false;
	}
}

if( ! function_exists( 'pod_media_get_current_screen' ) ) {
	function pod_media_get_current_screen() {
		global $pagenow;
		
		if ( $pagenow == 'post.php' ) {
		    return true;
		}
		return false;
	}
}
add_action( 'current_screen', 'pod_media_get_current_screen' );


if( ! function_exists('pod_add_post_formats') ) {
	function pod_add_post_formats() {

		//Activates and lists the post formats to be used.
		add_theme_support(
			'post-formats', array(
				'audio',
				'video'			
			)
		);
		
	}
}
add_action( 'after_setup_theme', 'pod_add_post_formats' );


/* File Meta Data ------------------------------ */

/**
 * thst_media_human_filesize()
 * Translates the size of a file into human readable format.
 *
 * @param int $bytes - Size of media file in bytes.
 * @param int $decimals - Amount of decimals to display.
 * @return string - Human readable file size.
 * @since 1.0
 */
if( ! function_exists( 'pod_media_human_filesize' ) ){
    function pod_media_human_filesize( $bytes, $decimals = 2 ) {
        $size = array('B','kB','MB','GB','TB','PB','EB','ZB','YB');
        $factor = floor((strlen($bytes) - 1) / 3);
        return sprintf("%.{$decimals}f", $bytes / pow(1024, $factor)) . @$size[$factor];
    }
}


/**
 * thst_media_key exists()
 * Checks if a particular key is contained in an array.
 *
 * @param string $key - Array key.
 * @param array $array - Empty array.
 * @return string $var
 * @since 1.0
 */
if( ! function_exists( 'pod_media_key_exists' ) ){
    function pod_media_key_exists( $key="", $array ){
        $var = '';
        if( is_array( $array ) ){
            if ( array_key_exists( $key, $array ) ) {
                $var = $array[$key];
            } else {
                $var = '';
            }
        }
        return $var;
    }
}


/**
 * thst_get_attachment_id_by_src()
 * Gets the attachment id of a media file by supplying the URL.
 *
 * @param string $media_src - src of the media file.
 * @return int $id - ID of the media file.
 * @since 1.0
 */
if( ! function_exists('thst_get_attachment_id_by_src') ) {
    function pod_get_attachment_id_by_src( $media_src ) {
        global $wpdb;
        $query = "SELECT ID FROM {$wpdb->posts} WHERE guid='$media_src'";
        $id = $wpdb->get_var($query);
        return $id;
    }
}

if( ! function_exists( "pod_get_media_meta_by_url" ) ) {
	function pod_get_media_meta_by_url( $media_url ) {
		$media_id = pod_get_attachment_id_by_src( $media_url );
		$media_meta = wp_get_attachment_metadata( $media_id );
		
		$array = array();
	    if( is_array( $media_meta ) ){
	        $media_artist = pod_media_key_exists('artist', $media_meta);
	        $media_title = get_the_title( $media_id );
	        $media_album = pod_media_key_exists('album', $media_meta);
	        $media_length = pod_media_key_exists('length_formatted', $media_meta);
	        $media_format = pod_media_key_exists('fileformat', $media_meta);
	        $media_bytes = pod_media_key_exists('filesize', $media_meta);
	        $media_bytes = is_numeric($media_bytes) ? $media_bytes : 0;
	        $media_size = pod_media_human_filesize($media_bytes);
	        
	        $array = array(
	            "artist"    => $media_artist,
	            "title"     => $media_title,
	            "album"     => $media_album,
	            "length"    => $media_length,
	            "format"    => $media_format,
	            "size"      => $media_size,
	        );
	    }
	    $output = $array;

	    if( ! empty( $array ) ){
	        return $output;
	    }
	}
}

/* Media Type */
if( ! function_exists( "pod_media_get_media_type" ) ) {
	function pod_media_get_media_type( $post_id ) {
		$format = get_post_format( $post_id );
		
		if( $format == "audio" ){
			$audio_type = get_post_meta( $post_id, 'cmb_thst_audio_type', true );
			return $audio_type;
			
		} elseif( $format == "video" ) {
			$video_type = get_post_meta( $post_id, 'cmb_thst_video_type', true );
			return $video_type;
		}
	}
}


/* Getters */
if( ! function_exists( "pod_get_media_url" ) ) {
	function pod_get_media_url( $post_id, $format ) {
		
		if( $format == "audio" ){
			$audio_type = get_post_meta( $post_id, 'cmb_thst_audio_type', true );

			if( $audio_type == 'audio-url' ) {
				$audio_url = get_post_meta( $post_id, 'cmb_thst_audio_url', true );
				return $audio_url;
			}
		} elseif( $format == "video" ) {
			$video_type = get_post_meta( $post_id, 'cmb_thst_video_type', true );

			if( $video_type == 'video-url' ) {
				$video_url = get_post_meta( $post_id, 'cmb_thst_video_url', true );
				return $video_url;
			}
		}
		return false;
	}
}

if( ! function_exists( "pod_get_media_oembed" ) ) {
	function pod_get_media_oembed( $post_id, $format ) {
		
		if( $format == "audio" ){
			$audio_type = get_post_meta( $post_id, 'cmb_thst_audio_type', true );

			if( $audio_type == 'audio-embed-url' ) {
				$audioembed = get_post_meta( $post_id, 'cmb_thst_audio_embed', true );
				return $audioembed;
			}

		} elseif( $format == "video" ) {
			$video_type = get_post_meta( $post_id, 'cmb_thst_video_type', true );

			if( $video_type == 'video-embed-url' ) {
				$videoembed = get_post_meta( $post_id, 'cmb_thst_video_embed', true );
				return $videoembed;
			}
		}
		return false;
	}
}

if( ! function_exists( "pod_get_media_embed_code" ) ) {
	function pod_get_media_embed_code( $post_id, $format ) {

		if( $format == "audio" ){
			$audio_type = get_post_meta( $post_id, 'cmb_thst_audio_type', true );

			if( $audio_type == 'audio-embed-code' ) {
				$audioembedcode = get_post_meta( $post_id, 'cmb_thst_audio_embed_code', true );
				return $audioembedcode;
			}

		} elseif( $format == "video" ) {
			$video_type = get_post_meta( $post_id, 'cmb_thst_video_type', true );

			if( $video_type == 'video-embed-code' ) {
				$videoembedcode = get_post_meta( $post_id, 'cmb_thst_video_embed_code', true );
				return $videoembedcode;
			}
		}
		return false;
	}
}


/* Duration */
if( ! function_exists( "pod_media_duration" ) ) {
	function pod_media_duration( $post_id ) {
		$format = get_post_format( $post_id );
		$media_url = pod_get_media_url( $post_id, $format );
		$media_meta = pod_get_media_meta_by_url( $media_url );
		$duration = $media_meta["length"];

		return $duration;
	}
}


/* Players */
if( ! function_exists( "pod_audio_player" ) ) {
	function pod_audio_player( $src ) {
		$o = '';

		$audio_shortcode_attr = array( 'src' => $src );
		$o .= wp_audio_shortcode( $audio_shortcode_attr );

		return $o;
	}
}

if( ! function_exists( "pod_video_player" ) ) {
	function pod_video_player( $src, $thumb ) {
		$o = '';

		$video_shortcode_attr = array( 'src' => $src, 'poster' => $thumb );
		$o .= wp_video_shortcode( $video_shortcode_attr );

		return $o;
	}
}

if( ! function_exists( "pod_audio_oembed" ) ) {
	function pod_audio_oembed( $url ) {
		$o = '';

		$audio_oembed_code = wp_oembed_get( $url );
		$o .= $audio_oembed_code;

		return $o;
	}
}

if( ! function_exists( "pod_video_oembed" ) ){
	function pod_video_oembed( $url ) {
		$o = '';

		$video_oembed_code = wp_oembed_get( $url );
		$o .= $video_oembed_code;

		return $o;
	}
}

if( ! function_exists( "pod_audio_embed" ) ) {
	function pod_audio_embed( $code ) {

		$o = $code;
		return $o;
	}
}
if( ! function_exists( "pod_video_embed" ) ) {
	function pod_video_embed( $code ) {

		$o = $code;
		return $o;
	}
}

if( ! function_exists( "pod_audio_playlist" ) ) {
	function pod_audio_playlist( $src_array ) {
		$o = '';

		$audio_playlist_ids = implode( ',', array_keys( $src_array ) );
		$audio_playlist_shortcode_attr = array( 'type' => 'audio', 'ids' => $audio_playlist_ids );
		$o .= wp_playlist_shortcode( $audio_playlist_shortcode_attr );

		return $o;
	}
}

if( ! function_exists( "pod_video_playlist" ) ) {
	function pod_video_playlist( $src_array ) {
		$o = '';

		$video_playlist_ids = implode( ',', array_keys( $src_array ) );
		$video_playlist_shortcode_attr = array( 'type' => 'video', 'ids' => $video_playlist_ids );
		$o .= wp_playlist_shortcode( $video_playlist_shortcode_attr );

		return $o;
	}
}

if( ! function_exists( "pod_media_player" ) ) {
	function pod_media_player( $format, $post_id ) {
		$o = '';

		if( $format == 'audio' ) {
			$audio_type = get_post_meta( $post_id, 'cmb_thst_audio_type', true );
			
			if( $audio_type == 'audio-url' ) {
				$audio_src = get_post_meta( $post_id, 'cmb_thst_audio_url', true );
				$o .= pod_audio_player( $audio_src );
			

			} elseif( $audio_type == 'audio-embed-url' ) {
				$audioembed = get_post_meta( $post_id, 'cmb_thst_audio_embed', true );
				$o .= pod_audio_oembed( $audioembed );
	 			

			} elseif( $audio_type == 'audio-embed-code' ) {
				$audioembedcode = get_post_meta( $post_id, 'cmb_thst_audio_embed_code', true );
				$o .= pod_audio_embed( $audioembedcode );
	 

			} elseif( $audio_type == 'audio-playlist' ){
				$src_array = get_post_meta( $post_id, 'cmb_thst_audio_playlist', true );
				$o .= pod_audio_playlist( $src_array );
			}

		} elseif( $format == 'video' ) {
			$video_type = get_post_meta( $post_id, 'cmb_thst_video_type', true );

			if( $video_type == 'video-url' ) {
				$video_src = get_post_meta( $post_id, 'cmb_thst_video_url', true );
				$video_thumb = get_post_meta( $post_id, 'cmb_thst_video_thumb', true );
				$o .= pod_video_player( $video_src, $video_thumb );


			} elseif( $video_type == 'video-oembed' ) {
				$videoembed = get_post_meta( $post_id, 'cmb_thst_video_embed', true );
				$o .= pod_video_oembed( $videoembed );


			} elseif( $video_type == 'video-embed-url' ) {
				$videoembedcode = get_post_meta( $post_id, 'cmb_thst_video_embed_code', true );
				$o .= pod_video_embed( $videoembedcode );

			
			} elseif( $video_type == 'video-playlist' ) {
				$src_array = get_post_meta( $post_id, 'cmb_thst_video_playlist', true );
				$o .= pod_video_playlist( $src_array );
			}

		}

		return $o;
	}
}

if( ! function_exists( "pod_player" ) ){
	function pod_player( $post_id ) {
		$format = get_post_format( $post_id );

		$o = pod_media_player( $format, $post_id );
		return $o;
	}
}

if( ! function_exists("pod_the_content") ) {
	function pod_the_content( $content ) {

	    $format = get_post_format();
	    $post_id = get_the_ID();

	    $output = '';

	    if ( ! post_password_required() ) {
	        $output = pod_player( $post_id );
	    }

	    if( is_single() ) {
	        $output .= $content;
	        return $output;
	    } else {
	        return $content;
	    }

	}
}

/* Only add filter if current theme or parent theme is not Podcaster */ 
$current_theme = wp_get_theme();
$current_parent_theme_args = wp_get_theme(get_template());
$current_parent_theme = $current_parent_theme_args->get( 'Name' );
if ( $current_theme != "Podcaster" && $current_parent_theme != "Podcaster" ) {
	add_filter( 'the_content', 'pod_the_content' );
}