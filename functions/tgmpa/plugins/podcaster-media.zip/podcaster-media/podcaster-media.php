<?php
/* Plugin Name: Podcaster Media
 * Plugin URI: http://www.themestation.co
 * Description: Add featured audio and video players to your posts.
 * Version: 1.3
 * Author: Theme Station
 * Author URI: http://www.themestation.co
 * Text Domain: podcaster-media
 */

if ( ! defined( 'ABSPATH' ) ) exit; 
// Exit if accessed directly

class PodMedia {
	function __construct(){
		
    	/* Plugin folder path */
    	if ( ! defined( 'PODMD_PLUGIN_DIR' ) ) {
    		define( 'PODMD_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
    	}

    	/* Plugin folder URL */
    	if ( ! defined( 'PODMD_PLUGIN_URL' ) ) {
    		define( 'PODMD_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
    	}
    	

        /* Load Widgets */
       	require_once( PODMD_PLUGIN_DIR .'includes/pod-metaboxes.php' );
        require_once( PODMD_PLUGIN_DIR .'includes/pod-media-functions.php' );
	

        add_action( 'plugins_loaded', array( $this, 'podcaster_media_load_plugin_textdomain' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'admin_init' ) );
	}

    function podcaster_media_load_plugin_textdomain() {
        load_plugin_textdomain( 'podcaster-media', FALSE, basename( dirname( __FILE__ ) ) . '/lang/' );
    }
	
    function admin_init(){

        /* Admin Scripts */
        wp_enqueue_script( 'jquery' );

        if( is_admin() ){
            
            if ( pod_media_is_gutenberg_active() ) {

                /* Gutenberg Admin Scripts */
                wp_enqueue_script( 'pod-media-admin-gutenberg', PODMD_PLUGIN_URL . 'assets/js/pod-media-admin-metabox-gutenberg.js', array('jquery'), '1.0', true );

            } else {

                /* Admin Scripts */
                wp_enqueue_script( 'pod-media-admin', PODMD_PLUGIN_URL . 'assets/js/pod-media-admin-metabox.js', array('jquery'), '1.0', true );

            }
        }
    }
}
new PodMedia(); ?>