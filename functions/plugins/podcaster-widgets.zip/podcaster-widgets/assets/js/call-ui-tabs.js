jQuery(document).ready(function($){
	$( "#featured-post-tabs-1" ).tabs().addClass( "ui-tabs-vertical ui-helper-clearfix" );
    $( "#featured-post-tabs-1 li" ).removeClass( "ui-corner-top" ).addClass( "ui-corner-left" );
});