jQuery(document).ready(function($) {
	/* Call Stellar. js*/
	$.stellar({
		horizontalOffset: 0,
		verticalOffset: 0,
		horizontalScrolling: false,
		responsive: true,
		parallaxBackgrounds: true,

	});
});