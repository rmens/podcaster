jQuery(document).ready(function(){
	jQuery('.post .entry-header').fitVids();
	jQuery('.post .entry-content').fitVids();
	jQuery('.video_player').fitVids();
});